function mmLoadMenus() {
 if (window.mm_menu_0724123858_0) return;
  window.mm_menu_0724123858_0 = new Menu("root",125,30,"Arial",10,"#666666","#333333","#CCCCCC","#d49e29","center","middle",0,0,100,0,0,true,true,true,0,false,false);
  mm_menu_0724123858_0.addMenuItem("Inteligencia&nbsp;Ambiental","location='../tecnologias/inteligencia.shtml'");
  mm_menu_0724123858_0.addMenuItem("Dom&oacute;tica","location='../tecnologias/domotica.shtml'");
  mm_menu_0724123858_0.addMenuItem("Tecnolog&iacute;as&nbsp;Inal&aacute;mbricas","location='../tecnologias/inalambricas.shtml'");
  mm_menu_0724123858_0.addMenuItem("RFID","location='../tecnologias/rfid.shtml'");
   mm_menu_0724123858_0.hideOnMouseOut=true;
   mm_menu_0724123858_0.bgColor='';
   mm_menu_0724123858_0.menuBorder=1;
   mm_menu_0724123858_0.menuLiteBgColor='#999999';
   mm_menu_0724123858_0.menuBorderBgColor='';

window.mm_menu_0724130618_0= new Menu("root",125,30,"Arial",10,"#666666","#333333","#CCCCCC","#d49e29","center","middle",3,0,100,0,0,true,true,true,0,true,true);

 
 mm_menu_0724130618_0.addMenuItem("Miner&iacute;a","location='../soluciones/mineria.shtml'");
 mm_menu_0724130618_0.addMenuItem("Sanidad","location='../soluciones/hospitales.shtml'");
  mm_menu_0724130618_0.addMenuItem("Congresos&nbsp;y&nbsp;Ferias","location='../soluciones/congresos.shtml'"); 
 mm_menu_0724130618_0.addMenuItem("Hogar","location='../soluciones/domotica.shtml'");
 



   mm_menu_0724130618_0.hideOnMouseOut=true;
   mm_menu_0724130618_0.bgColor='';
   mm_menu_0724130618_0.menuBorder=1;
   mm_menu_0724130618_0.menuLiteBgColor='#999999';
   mm_menu_0724130618_0.menuBorderBgColor='';
   
   window.mm_menu_07241306133_0= new Menu("root",125,30,"Arial",10,"#666666","#333333","#CCCCCC","#d49e29","center","middle",3,0,100,0,0,true,true,true,0,true,true);
  mm_menu_07241306133_0.addMenuItem("Hugs","location='../productos/hugs.shtml' ");
 
 mm_menu_07241306133_0.addMenuItem("Roam Alert","location='../productos/roam.shtml'");
 mm_menu_07241306133_0.addMenuItem("Medicom","location='../productos/medicom.shtml'");
  mm_menu_07241306133_0.addMenuItem("Control 4","location='../productos/control4.shtml'"); 


   mm_menu_07241306133_0.hideOnMouseOut=true;
   mm_menu_07241306133_0.bgColor='';
   mm_menu_07241306133_0.menuBorder=1;
   mm_menu_07241306133_0.menuLiteBgColor='#999999';
   mm_menu_07241306133_0.menuBorderBgColor='';
   
    window.mm_menu_0724124905_0 = new Menu("root",125,30,"Arial",10,"#666666","#333333","#CCCCCC","#d49e29","center","middle",3,0,100,0,0,true,true,true,0,true,true);
     mm_menu_0724124905_0.addMenuItem("Universidades","location='../colaboradores/universidades.shtml'");
	 	    mm_menu_0724124905_0.addMenuItem("Compa&ntilde;&iacute;as &amp; Empresas","location='../colaboradores/empresas.shtml'");
	  mm_menu_0724124905_0.addMenuItem("Administraci&oacute;n P&uacute;blica","location='../colaboradores/administracion.shtml'");


	    mm_menu_0724124905_0.addMenuItem("Sociedad Civil &amp; Otros","location='../colaboradores/fundaciones.shtml'");
   mm_menu_0724124905_0.hideOnMouseOut=true;
   mm_menu_0724124905_0.bgColor='';
   mm_menu_0724124905_0.menuBorder=1;
   mm_menu_0724124905_0.menuLiteBgColor='#999999';
   mm_menu_0724124905_0.menuBorderBgColor='';
       window.mm_menu_0724130619_0 =  new Menu("root",125,30,"Arial",10,"#666666","#333333","#CCCCCC","#d49e29","center","middle",3,0,100,0,0,true,true,true,0,true,true);
	   
	   
	     mm_menu_0724130619_0.addMenuItem("Hugs","location='../productos/casosHugs.shtml' ");
 
 mm_menu_0724130619_0.addMenuItem("Roam Alert","location='../productos/roamCasos.shtml'");
 mm_menu_0724130619_0.addMenuItem("Medicom","location='../productos/mediCasos.shtml'");
  
 

   mm_menu_0724130619_0.hideOnMouseOut=true;
   mm_menu_0724130619_0.bgColor='';
   mm_menu_0724130619_0.menuBorder=1;
   mm_menu_0724130619_0.menuLiteBgColor='#999999';
   mm_menu_0724130619_0.menuBorderBgColor='';

mm_menu_0724130619_0.writeMenus();
} 


function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}


	

function findObj(n, d) {

  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {

    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}

  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];

  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);

  if(!x && d.getElementById) x=d.getElementById(n); return x;

}

	function showVisi(id) {

		var all = document.getElementsByTagName("ul");

		for (var loop=0; loop < all.length; loop++) {

			all[loop].style.display = "none";

		}

		document.getElementById(id).style.display = "block";

	}



	



function swapType(type){

	iExt = type;

}







	function Item(){

  this.length = Item.arguments.length 

  for (var i = 0; i < this.length; i++)

    this[i] = Item.arguments[i];

}







function Fecha() {

  var ndia  = new Item('Domingo', 'Lunes', 'Martes', 'Mi&eacute;rcoles', 'Jueves', 'Viernes', 'S&aacute;bado')

  var nmes  = new Item('Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 

                          'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre')

  var ahora

  var fecha = new Date()

  var anno   = fecha.getYear()

  var mes   = fecha.getMonth()

  var dia   = fecha.getDay()

  var aux   = "" + fecha

  

  if (anno<10) {

    anno2 = "200" + eval(anno)

  }

  else if (anno<80) {                // anno tiene 2 d�gitos 19xx (m�s de 80)

    anno2 = "20" + anno

  } 

  else if (anno<=99) {               // anno tiene 2 d�gitos 20xx (menor de 80)

    anno2 = "19" + anno

  }

  else if (anno<1000) {              // anno tiene 3 d�gitos (100 es 2000)

    anno2 = eval(anno) + eval(1900)

  }

  else {

    anno2 = anno                      // anno tiene 4 d�gitos

  }

  ahora = ndia[dia] + ", " + eval(aux.substring(7, 10)) + " " + nmes[mes] + " " + anno2

  return ahora

}

/////////////////////////////////////////////////////////////////



function movstar(a,time){

	movx=setInterval("mov("+a+")",1)

	}

function movover(){

	clearInterval(movx)

	}

function mov(a){

	scrollx=win1.document.body.scrollLeft

	scrolly=win1.document.body.scrollTop

	scrolly=scrolly+a

	win1.window.scroll(scrollx,scrolly)

	}

function o_down(theobject){

object=theobject

	while(object.filters.alpha.opacity>60){

		object.filters.alpha.opacity+=-10}

		}

function o_up(theobject){

object=theobject

	while(object.filters.alpha.opacity<100){

		object.filters.alpha.opacity+=10}

		}

function wback(){

	if(new_date.history.length==0){window.history.back()}

	else{new_date.history.back()}

	}

	



function agregar(){

   if ((navigator.appName=="Microsoft Internet Explorer") && 

         (parseInt(navigator.appVersion)>=4)) {

      var url="index.html"; 

      var titulo="bossdport Spa: Centro Deportivo Talavera";

      window.external.AddFavorite(url,titulo);

   } else { 

      if(navigator.appName == "Netscape") 

         alert("Presione Crtl+D para agregar este sitio en sus Favoritos"); 

   }

} 
function CambiarEstiloOculto(id) {
	var elemento = document.getElementById(id);
	if (elemento.className == "oculto") {
	elemento.className = "visible";

	}
	else {
	elemento.className = "oculto";
	}

}
function CambiarEstiloSelect(id) {
	var elemento = document.getElementById(id);
	if (elemento.className == "select") {
	elemento.className = "noselect";

	}
	else {
	elemento.className = "select";
	}

}

// Browser Slide-Show script.
// With image cross fade effect for those browsers that support it.
var slideCache = new Array();
function RunSlideShow(pictureName,imageFiles,displaySecs)
{
var imageSeparator = imageFiles.indexOf(";");
var nextImage = imageFiles.substring(0,imageSeparator);
if (document.all)
{
document.getElementById(pictureName).style.filter="blendTrans(duration=2)";
document.getElementById(pictureName).filters.blendTrans.Apply();
}
document.getElementById(pictureName).src = nextImage;
if (document.all)
{
document.getElementById(pictureName).filters.blendTrans.Play();
}
var futureImages= imageFiles.substring(imageSeparator+1,imageFiles.length)
+ ';' + nextImage;
setTimeout("RunSlideShow('"+pictureName+"','"+futureImages+"',"+displaySecs+")",
displaySecs*1000);
// Cache the next image to improve performance.
imageSeparator = futureImages.indexOf(";");
nextImage = futureImages.substring(0,imageSeparator);
if (slideCache[nextImage] == null) {
slideCache[nextImage] = new Image;
slideCache[nextImage].src = nextImage;
}
}

var theObj="";
 







 
function setActiveStyleSheet(title) {
   var i, a, main;
   for(i=0; (a = document.getElementsByTagName("link")[i]); i++) {
     if(a.getAttribute("rel").indexOf("style") != -1
        && a.getAttribute("title")) {
       a.disabled = true;
       if(a.getAttribute("title") == title) a.disabled = false;
     }
   }
}


function validarCompleto(form)
{
		//alert ("funciona");
	val=validar_vacio(form);
	//alert (val);
	if(!numeric(form.telefono.value))
	{
				alert("Numero de tel�fono incorrecto intentelo de nuevo.");
				val=false;
				return false;
	}
	//alert (val)
	if(val==true)
	{



form.submit();
	}
}

function validar_vacio(form)
{
	for (i = 0; i < form.elements.length; i++) {
		if (form.elements[i].type == "text" && form.elements[i].value == "") { 
			alert("Por favor complete todos los campos del formulario"); 
			form.elements[i].focus(); 
			return false; 
		}
	}
	return true;
	
}
function numeric(s)
{   
	var i;
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (! isDigit(c))
        return false;
    }

    return true;
}
function isDigit (c)
{   
	return ((c >= "0") && (c <= "9"))
}


function datos_trabaja(form)
{
val=true;
		if (form.nombre.value == "") { 
			alert("Por favor introduzca un nombre"); 
			form.nombre.focus(); 
			val=false;
			return false; 
		}
		if (form.apellidos.value == "") { 
			alert("Por favor introduzca los apellidos"); 
			form.fecha_fin.focus(); 
			val=false;

			return false; 
		}
		if (form.direccion.value == "") { 
			alert("Por favor introduzca la direcci&oacute;n"); 
			form.comentarios.focus(); 
			val=false;

			return false; 
		}
		if (form.email.value == "") { 
			alert("Por favor introduzca su email"); 
			form.comentarios.focus(); 
			val=false;

			return false; 
		}
				if (form.fijo.value == "") { 
			alert("Por favor introduzca su tel&eacute;fono fijo"); 
			form.comentarios.focus(); 
			val=false;

			return false; 
		}
			if (form.comentarios.value == "") { 
			alert("Por favor introduzca sus comentarios"); 
			form.comentarios.focus(); 
			val=false;

			return false; 
		}
		
			
	if(val==true)
	{
		form.submit();
	}
}